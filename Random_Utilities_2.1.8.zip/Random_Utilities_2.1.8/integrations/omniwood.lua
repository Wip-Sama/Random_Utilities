appmod.blacklist['omnimutator'] = true
